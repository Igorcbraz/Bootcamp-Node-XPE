export function soma(a, b) {
  return a + b;
}

export function subtrai(a, b) {
  return a - b;
}

export const PI = 3.14;

console.log("Carregou modulo 1");
