
function imprimeOla3() {
  var nome = 'Danilo';
  console.log(m);
  console.log(nome);
}

imprimeOla3();
