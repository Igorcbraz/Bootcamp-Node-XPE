import * as m1 from "./modulo1.js";

console.log(m1.soma(m1.PI, 2));
console.log(m1.subtrai(2, 2));
